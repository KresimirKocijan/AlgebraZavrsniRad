<div class="well">
                    <h4>Ulogirajte se!</h4>
                    <form method="POST" action="login.php">
                    <div class="">
                         <input name="user_name" type="text" class="form-control" placeholder="Upišite korisničko ime" required>
                         <br>
                    </div>

                    <div class="input-group">
                        <input name="user_password" type="password" class="form-control" placeholder="Upišite lozinku" required>
                        <br>
                        <span class="input-group-btn">
                            <button name="login" class="btn btn-primary" type="submit">Potvrdi!</button>
                        </span>
                    </div>
                    </form>
                </div>

<div>
 <img src="https://upload.wikimedia.org/wikipedia/en/thumb/0/0c/Liverpool_FC.svg/1200px-Liverpool_FC.svg.png" style="width:360px;height:450px;">
</div>

<div>
    <br><br><br>
<div id="scoreaxis-widget-18b91" style="border-width:1px;border-color:rgba(0, 0, 0, 0.15);border-style:solid;border-radius:8px;padding:10px;background:rgb(255, 255, 255);width:100%" data-reactroot=""><iframe id="Iframe" src="https://www.scoreaxis.com/widget/standings-widget/8?&amp;inst=18b91" style="width:100%;border:none;transition:all 300ms ease"></iframe><script>window.addEventListener("DOMContentLoaded",event=>{window.addEventListener("message",event=>{if(event.data.appHeight&&"18b91"==event.data.inst){let container=document.querySelector("#scoreaxis-widget-18b91 iframe");container&&(container.style.height=parseInt(event.data.appHeight)+"px")}},!1)});</script></div>
</div>

         

