 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:left; font-family: 'Monotype Corsiva'; font-size:17px;"><b>Izradio: Krešimir Kocijan</b></p>
                </div>
            </div>
   </footer>