<nav style="background-color:red;" class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container">


				<div class="navbar-header">
					 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span style="color:white;" class="sr-only"><strong>Navigacija</strong></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php" style="color:white; font-size:25px;"><strong>Liverpool FC Novosti </strong></a>
				</div>

				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					
                   	 <ul class="nav navbar-nav">
                    	<li><a href="about.php" style="color:white;"><strong>Više o stranici</strong></a></li>
						 <li class="navbar-nav"><a href="register.php" style="color:white;"><strong>Registriraj se!</strong></a></li>
                   	 </ul>
					
				</div>
			</div>
	    </nav>