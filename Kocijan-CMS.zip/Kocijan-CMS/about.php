<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-8">
            <h1 class="page-header"><strong>Više o stranici</strong></h1>
            <h3> Ovo je CMS kreiran u Laravel frameworku u sklopu tečaja backend developmenta.</h3>
            <br><br><br>

          <h4><strong>Značajke CMS-a:</strong></h4>
          > Povezivanje s bazom <br>
          > Sustav za autorizaciju i autentifikaciju korisnika<br>
          > Sustav za upravljanje korisnicima <br>
          > Sustav za upravljanje ulogama korisnika <br>
          > Sustav za upravljanje stranicama <br>
          > Navigacija stranicama <br>
         
          <br> <br> 

          <h4><strong>Značajke contenta:</strong></h4>
          > Tematika CMS-a su zbivanja vezana uz nogometni klub Liverpool FC <br>
          > Svrha CMS-a je upravljanje contentom, odnosno dodavanje, uređivanje i brisanje članaka 
          <br> <br> <br>

           <h4><strong>Korišteni alati:</strong></h4>
           <strong>Front-End:</strong> HTML, CSS <br>
           <strong>Back-End:</strong> PHP       <br>
           <br>

           <h4><strong>Izradio:</strong></h4>
           <strong>Ime:</strong> Krešimir Kocijan <br>
           <strong>E-mail:</strong> kocijankresimir1@gmail.com <br>
           <br><br>
          
           <img src="https://pbs.twimg.com/media/FeOp18HXEAIvdiR?format=jpg&name=4096x4096" style="width:700px;height:500px;">

        </div>

             <div class="col-md-4">

               <?php include 'includes/sidebar.php';
?><!-- Footer -->
</div>
</div>
</div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>